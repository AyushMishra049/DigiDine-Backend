package com.digidine.digidine;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DigidineApplicationTests {

	@Test
	void contextLoads() {
	}

}
